﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Display = New System.Windows.Forms.TextBox()
        Me.Btn1 = New System.Windows.Forms.Button()
        Me.Btn2 = New System.Windows.Forms.Button()
        Me.Btn3 = New System.Windows.Forms.Button()
        Me.BtnAdd = New System.Windows.Forms.Button()
        Me.Btn4 = New System.Windows.Forms.Button()
        Me.Btn5 = New System.Windows.Forms.Button()
        Me.Btn6 = New System.Windows.Forms.Button()
        Me.BtnMinus = New System.Windows.Forms.Button()
        Me.Btn7 = New System.Windows.Forms.Button()
        Me.Btn8 = New System.Windows.Forms.Button()
        Me.Btn9 = New System.Windows.Forms.Button()
        Me.BtnMultiply = New System.Windows.Forms.Button()
        Me.BtnZero = New System.Windows.Forms.Button()
        Me.Btndot = New System.Windows.Forms.Button()
        Me.Btnclear = New System.Windows.Forms.Button()
        Me.BtnDivide = New System.Windows.Forms.Button()
        Me.BtnPtg = New System.Windows.Forms.Button()
        Me.Btnsrt = New System.Windows.Forms.Button()
        Me.BtnPwr = New System.Windows.Forms.Button()
        Me.BtnInverse = New System.Windows.Forms.Button()
        Me.BtnCalculate = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Display
        '
        Me.Display.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Display.Location = New System.Drawing.Point(30, 110)
        Me.Display.Name = "Display"
        Me.Display.Size = New System.Drawing.Size(318, 23)
        Me.Display.TabIndex = 0
        Me.Display.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        '
        'Btn1
        '
        Me.Btn1.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn1.Location = New System.Drawing.Point(30, 136)
        Me.Btn1.Name = "Btn1"
        Me.Btn1.Size = New System.Drawing.Size(75, 23)
        Me.Btn1.TabIndex = 1
        Me.Btn1.Text = "1"
        Me.Btn1.UseVisualStyleBackColor = True
        '
        'Btn2
        '
        Me.Btn2.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn2.Location = New System.Drawing.Point(111, 136)
        Me.Btn2.Name = "Btn2"
        Me.Btn2.Size = New System.Drawing.Size(75, 23)
        Me.Btn2.TabIndex = 2
        Me.Btn2.Text = "2"
        Me.Btn2.UseVisualStyleBackColor = True
        '
        'Btn3
        '
        Me.Btn3.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn3.Location = New System.Drawing.Point(192, 136)
        Me.Btn3.Name = "Btn3"
        Me.Btn3.Size = New System.Drawing.Size(75, 23)
        Me.Btn3.TabIndex = 3
        Me.Btn3.Text = "3"
        Me.Btn3.UseVisualStyleBackColor = True
        '
        'BtnAdd
        '
        Me.BtnAdd.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnAdd.Location = New System.Drawing.Point(273, 136)
        Me.BtnAdd.Name = "BtnAdd"
        Me.BtnAdd.Size = New System.Drawing.Size(75, 23)
        Me.BtnAdd.TabIndex = 4
        Me.BtnAdd.Text = "+"
        Me.BtnAdd.UseVisualStyleBackColor = True
        '
        'Btn4
        '
        Me.Btn4.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn4.Location = New System.Drawing.Point(30, 165)
        Me.Btn4.Name = "Btn4"
        Me.Btn4.Size = New System.Drawing.Size(75, 23)
        Me.Btn4.TabIndex = 1
        Me.Btn4.Text = "4"
        Me.Btn4.UseVisualStyleBackColor = True
        '
        'Btn5
        '
        Me.Btn5.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn5.Location = New System.Drawing.Point(111, 165)
        Me.Btn5.Name = "Btn5"
        Me.Btn5.Size = New System.Drawing.Size(75, 23)
        Me.Btn5.TabIndex = 2
        Me.Btn5.Text = "5"
        Me.Btn5.UseVisualStyleBackColor = True
        '
        'Btn6
        '
        Me.Btn6.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn6.Location = New System.Drawing.Point(192, 165)
        Me.Btn6.Name = "Btn6"
        Me.Btn6.Size = New System.Drawing.Size(75, 23)
        Me.Btn6.TabIndex = 3
        Me.Btn6.Text = "6"
        Me.Btn6.UseVisualStyleBackColor = True
        '
        'BtnMinus
        '
        Me.BtnMinus.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnMinus.Location = New System.Drawing.Point(273, 165)
        Me.BtnMinus.Name = "BtnMinus"
        Me.BtnMinus.Size = New System.Drawing.Size(75, 23)
        Me.BtnMinus.TabIndex = 4
        Me.BtnMinus.Text = "-"
        Me.BtnMinus.UseVisualStyleBackColor = True
        '
        'Btn7
        '
        Me.Btn7.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn7.Location = New System.Drawing.Point(30, 194)
        Me.Btn7.Name = "Btn7"
        Me.Btn7.Size = New System.Drawing.Size(75, 23)
        Me.Btn7.TabIndex = 1
        Me.Btn7.Text = "7"
        Me.Btn7.UseVisualStyleBackColor = True
        '
        'Btn8
        '
        Me.Btn8.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn8.Location = New System.Drawing.Point(111, 194)
        Me.Btn8.Name = "Btn8"
        Me.Btn8.Size = New System.Drawing.Size(75, 23)
        Me.Btn8.TabIndex = 2
        Me.Btn8.Text = "8"
        Me.Btn8.UseVisualStyleBackColor = True
        '
        'Btn9
        '
        Me.Btn9.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btn9.Location = New System.Drawing.Point(192, 194)
        Me.Btn9.Name = "Btn9"
        Me.Btn9.Size = New System.Drawing.Size(75, 23)
        Me.Btn9.TabIndex = 3
        Me.Btn9.Text = "9"
        Me.Btn9.UseVisualStyleBackColor = True
        '
        'BtnMultiply
        '
        Me.BtnMultiply.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnMultiply.Location = New System.Drawing.Point(273, 194)
        Me.BtnMultiply.Name = "BtnMultiply"
        Me.BtnMultiply.Size = New System.Drawing.Size(75, 23)
        Me.BtnMultiply.TabIndex = 4
        Me.BtnMultiply.Text = "x"
        Me.BtnMultiply.UseVisualStyleBackColor = True
        '
        'BtnZero
        '
        Me.BtnZero.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnZero.Location = New System.Drawing.Point(30, 223)
        Me.BtnZero.Name = "BtnZero"
        Me.BtnZero.Size = New System.Drawing.Size(75, 23)
        Me.BtnZero.TabIndex = 1
        Me.BtnZero.Text = "0"
        Me.BtnZero.UseVisualStyleBackColor = True
        '
        'Btndot
        '
        Me.Btndot.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btndot.Location = New System.Drawing.Point(111, 223)
        Me.Btndot.Name = "Btndot"
        Me.Btndot.Size = New System.Drawing.Size(75, 23)
        Me.Btndot.TabIndex = 2
        Me.Btndot.Text = "."
        Me.Btndot.UseVisualStyleBackColor = True
        '
        'Btnclear
        '
        Me.Btnclear.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnclear.Location = New System.Drawing.Point(192, 223)
        Me.Btnclear.Name = "Btnclear"
        Me.Btnclear.Size = New System.Drawing.Size(75, 23)
        Me.Btnclear.TabIndex = 3
        Me.Btnclear.Text = "c"
        Me.Btnclear.UseVisualStyleBackColor = True
        '
        'BtnDivide
        '
        Me.BtnDivide.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnDivide.Location = New System.Drawing.Point(273, 223)
        Me.BtnDivide.Name = "BtnDivide"
        Me.BtnDivide.Size = New System.Drawing.Size(75, 23)
        Me.BtnDivide.TabIndex = 4
        Me.BtnDivide.Text = "÷"
        Me.BtnDivide.UseVisualStyleBackColor = True
        '
        'BtnPtg
        '
        Me.BtnPtg.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPtg.Location = New System.Drawing.Point(30, 252)
        Me.BtnPtg.Name = "BtnPtg"
        Me.BtnPtg.Size = New System.Drawing.Size(75, 23)
        Me.BtnPtg.TabIndex = 1
        Me.BtnPtg.Text = "%"
        Me.BtnPtg.UseVisualStyleBackColor = True
        '
        'Btnsrt
        '
        Me.Btnsrt.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Btnsrt.Location = New System.Drawing.Point(111, 252)
        Me.Btnsrt.Name = "Btnsrt"
        Me.Btnsrt.Size = New System.Drawing.Size(75, 23)
        Me.Btnsrt.TabIndex = 2
        Me.Btnsrt.Text = "√"
        Me.Btnsrt.UseVisualStyleBackColor = True
        '
        'BtnPwr
        '
        Me.BtnPwr.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnPwr.Location = New System.Drawing.Point(192, 252)
        Me.BtnPwr.Name = "BtnPwr"
        Me.BtnPwr.Size = New System.Drawing.Size(75, 23)
        Me.BtnPwr.TabIndex = 3
        Me.BtnPwr.Text = "x²"
        Me.BtnPwr.UseVisualStyleBackColor = True
        '
        'BtnInverse
        '
        Me.BtnInverse.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnInverse.Location = New System.Drawing.Point(273, 252)
        Me.BtnInverse.Name = "BtnInverse"
        Me.BtnInverse.Size = New System.Drawing.Size(75, 23)
        Me.BtnInverse.TabIndex = 4
        Me.BtnInverse.Text = "⅟ x"
        Me.BtnInverse.UseVisualStyleBackColor = True
        '
        'BtnCalculate
        '
        Me.BtnCalculate.Font = New System.Drawing.Font("Microsoft Sans Serif", 10.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BtnCalculate.Location = New System.Drawing.Point(30, 281)
        Me.BtnCalculate.Name = "BtnCalculate"
        Me.BtnCalculate.Size = New System.Drawing.Size(318, 19)
        Me.BtnCalculate.TabIndex = 1
        Me.BtnCalculate.Text = "="
        Me.BtnCalculate.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ActiveCaption
        Me.ClientSize = New System.Drawing.Size(393, 377)
        Me.Controls.Add(Me.BtnInverse)
        Me.Controls.Add(Me.BtnDivide)
        Me.Controls.Add(Me.BtnMultiply)
        Me.Controls.Add(Me.BtnMinus)
        Me.Controls.Add(Me.BtnAdd)
        Me.Controls.Add(Me.BtnPwr)
        Me.Controls.Add(Me.Btnclear)
        Me.Controls.Add(Me.Btn9)
        Me.Controls.Add(Me.Btn6)
        Me.Controls.Add(Me.Btn3)
        Me.Controls.Add(Me.Btnsrt)
        Me.Controls.Add(Me.Btndot)
        Me.Controls.Add(Me.Btn8)
        Me.Controls.Add(Me.Btn5)
        Me.Controls.Add(Me.Btn2)
        Me.Controls.Add(Me.BtnCalculate)
        Me.Controls.Add(Me.BtnPtg)
        Me.Controls.Add(Me.BtnZero)
        Me.Controls.Add(Me.Btn7)
        Me.Controls.Add(Me.Btn4)
        Me.Controls.Add(Me.Btn1)
        Me.Controls.Add(Me.Display)
        Me.Name = "Form1"
        Me.Text = "Urenna Calculator"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents Display As TextBox
    Friend WithEvents Btn1 As Button
    Friend WithEvents Btn2 As Button
    Friend WithEvents Btn3 As Button
    Friend WithEvents BtnAdd As Button
    Friend WithEvents Btn4 As Button
    Friend WithEvents Btn5 As Button
    Friend WithEvents Btn6 As Button
    Friend WithEvents BtnMinus As Button
    Friend WithEvents Btn7 As Button
    Friend WithEvents Btn8 As Button
    Friend WithEvents Btn9 As Button
    Friend WithEvents BtnMultiply As Button
    Friend WithEvents BtnZero As Button
    Friend WithEvents Btndot As Button
    Friend WithEvents Btnclear As Button
    Friend WithEvents BtnDivide As Button
    Friend WithEvents BtnPtg As Button
    Friend WithEvents Btnsrt As Button
    Friend WithEvents BtnPwr As Button
    Friend WithEvents BtnInverse As Button
    Friend WithEvents BtnCalculate As Button
End Class
